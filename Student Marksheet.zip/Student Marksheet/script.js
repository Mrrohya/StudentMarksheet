function generateMarksheet() {
    // Get input values from the form
    var name = document.getElementById("name").value;
    var fatherName = document.getElementById("fatherName").value;
    var institute = document.getElementById("institute").value;
    var batch = document.getElementById("batch").value;
    var division = document.getElementById("division").value;
    var rollNo = document.getElementById("rollNo").value;
    var subject1 = parseInt(document.getElementById("subject1").value);
    var subject2 = parseInt(document.getElementById("subject2").value);

    // Calculate total marks
    var totalMarks = subject1 + subject2;

    // Determine pass or fail
    var passFail = (subject1 >= 40 && subject2 >= 40) ? "Pass" : "Fail";

    // Generate the marksheet output
    var marksheetOutput = `
        <h2>Student Marksheet</h2>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Father's Name:</strong> ${fatherName}</p>
        <p><strong>Institute Name:</strong> ${institute}</p>
        <p><strong>Batch:</strong> ${batch}</p>
        <p><strong>Division/Board:</strong> ${division}</p>
        <p><strong>Roll No:</strong> ${rollNo}</p>
        <table>
            <tr>
                <th>Subject</th>
                <th>Marks</th>
            </tr>
            <tr>
                <td>Subject 1</td>
                <td>${subject1}</td>
            </tr>
            <tr>
                <td>Subject 2</td>
                <td>${subject2}</td>
            </tr>
            <tr>
                <th>Total Marks</th>
                <th>${totalMarks}</th>
            </tr>
        </table>
        <p><strong>Status:</strong> ${passFail}</p>
    `;

    // Display the marksheet output
    var marksheetOutputDiv = document.getElementById("marksheetOutput");
    marksheetOutputDiv.innerHTML = marksheetOutput;
}

